import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.sql.*;

public class JobDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static void save(job j){
		int status=0;
		int jid=j.getJid();
		int apid=10+jid;
		try{
			Connection con=JobDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into appliedjob(apid,jid) values (?,?)");
			
		
			ps.setInt(1,apid);
			ps.setInt(2,j.getJid());
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
	}
		
	public static List<job> getAllJobs(int jid){
		List<job> list=new ArrayList<job>();
		
		try{
			Connection con=JobDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from job where jid=?");
			ps.setInt(1,jid);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				job j=new job();
				j.setJid(rs.getInt(1));
				j.setJname(rs.getString(2));
				j.setCname(rs.getString(3));
				j.setJobtype(rs.getString(4));
				j.setLocation(rs.getString(5));
				j.setJd(rs.getString(6));
				list.add(j);
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return list;
}
}