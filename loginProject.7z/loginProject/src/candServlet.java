

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/candServlet")
public class candServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String x=request.getParameter("jid");
		int a=Integer.parseInt(x);
	
		List<job> list=JobDao.getAllJobs(a);
		
	
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Jid</th><th>Job name</th><th>Company Name</th><th>Job type</th><th>Location</th><th>Job description</th><th></th></tr>");
		for(job j:list){
			out.print("<tr><td>"+j.getJid()+"</td><td>"+j.getJname()+"</td><td>"+j.getCname()+"</td><td>"+j.getJobtype()+"</td><td>"+j.getLocation()+"</td><td>"+j.getJd()+"</td><td><a href='appliedServlet?jid="+j.getJid()+"'>apply</a></td><td></td></tr>");
		}
		out.print("</table>");
		
		
		
		request.getRequestDispatcher("Jobtable.html").include(request, response);
		
		
		
		out.close();
	}

}
