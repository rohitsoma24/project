

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/appliedServlet")
public class appliedServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String apid=request.getParameter("jid");
		int id=Integer.parseInt(apid);
		
		job j=new job();
		j.setJid(id);
		
		JobDao.save(j);
		out.print("<p>Record saved successfully!</p>");
			request.getRequestDispatcher("candindex.html").include(request, response);
		
		
		out.close();
	}

}
